Imports System.Data 'CommandType
Imports System.Data.SqlClient 'sqlconnection,sqlcommand,sqlDataReades
Imports System.Collections.Generic 'List(Of)
Imports Demo01.Librerias.EntidadesNegocio 'beEmpleados
Imports System.Configuration 'ConfigurationManager


Public Class daEmpleado
    Public Function Listar() As List(Of beEmpleado)
        Dim lbeEmpleado As List(Of beEmpleado) = Nothing
        Dim strConexion As String = ConfigurationManager.ConnectionStrings("conNW").ConnectionString
        Using con As New SqlConnection(strConexion)
            con.Open()
            Dim cmd As New SqlCommand("uspSabados001", con)
            Dim drd As SqlDataReader = cmd.ExecuteReader()
            If drd IsNot Nothing Then
                lbeEmpleado = New List(Of beEmpleado)
                Dim obeEmpleado As beEmpleado
                Dim posidEmpleado As Integer = drd.GetOrdinal("EmployeeID")
                While drd.Read
                    obeEmpleado = New beEmpleado
                    obeEmpleado.IdEmpleado = drd.Getint32(0)
                    obeEmpleado.Apellido = drd.GetString(1)
                    obeEmpleado.Nombre = drd.GetString(2)
                    obeEmpleado.FechaNacimiento = drd.GetDateTime(3)

                End While
            End If
        End Using 'con.close() con.Dispose() con=Nothing
        Return lbeEmpleado
    End Function
End Class
