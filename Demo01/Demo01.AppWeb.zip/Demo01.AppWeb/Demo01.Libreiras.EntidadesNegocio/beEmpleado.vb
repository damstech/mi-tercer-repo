Public Class Class1
    Public Property IdEmpleado As Integer
    Public Property Apellido As String
    Public Property Nombre As String
    Public Property FechaNacimiento As DateTime

End Class
